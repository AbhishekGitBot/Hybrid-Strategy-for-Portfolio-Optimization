from flask import Flask, render_template, request, jsonify
import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime
import plotly
import plotly.graph_objs as go
from plotly.subplots import make_subplots
import json

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_stock_data', methods=['POST'])
def get_stock_data():
    try:
        data = request.json
        ticker = data['ticker']
        start_year = int(data['start_year'])
        end_year = int(data['end_year'])
        
        # Get stock data
        stock = yf.Ticker(ticker)
        df = stock.history(start=f"{start_year}-01-01", end=f"{end_year}-12-31")
        
        # Calculate log returns
        df['Log_Return'] = np.log(df['Close'] / df['Close'].shift(1))
        
        # Create subplot figure with secondary y-axis
        fig = make_subplots(
            rows=2, cols=1,
            subplot_titles=(f'{ticker} Stock Price', f'{ticker} Log Returns'),
            vertical_spacing=0.2,
            row_heights=[0.7, 0.3]
        )

        # Add candlestick chart
        fig.add_trace(
            go.Candlestick(
                x=df.index,
                open=df['Open'],
                high=df['High'],
                low=df['Low'],
                close=df['Close'],
                name='OHLC'
            ),
            row=1, col=1
        )
        
        # Add log returns
        fig.add_trace(
            go.Scatter(
                x=df.index,
                y=df['Log_Return'],
                mode='lines',
                name='Log Returns',
                line=dict(color='rgb(49,130,189)')
            ),
            row=2, col=1
        )

        # Update layout for better visualization
        fig.update_layout(
            title_text=f"{ticker} Stock Analysis",
            template='plotly_dark',
            height=900,  # Increase overall height to accommodate both plots
            showlegend=True,
            xaxis_rangeslider_visible=False  # Disable rangeslider for cleaner look
        )

        # Update y-axes labels
        fig.update_yaxes(title_text="Price", row=1, col=1)
        fig.update_yaxes(title_text="Log Return", row=2, col=1)

        # Update x-axes labels
        fig.update_xaxes(title_text="Date", row=2, col=1)
        
        # Convert the plot to JSON
        graphJSON = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
        
        # Calculate some basic statistics for log returns
        stats = {
            'mean_return': df['Log_Return'].mean(),
            'std_return': df['Log_Return'].std(),
            'min_return': df['Log_Return'].min(),
            'max_return': df['Log_Return'].max()
        }
        
        return jsonify({
            'status': 'success',
            'plot': graphJSON,
            'stats': stats,
            'message': 'Data retrieved successfully'
        })
    
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        })

if __name__ == '__main__':
    app.run(debug=True)